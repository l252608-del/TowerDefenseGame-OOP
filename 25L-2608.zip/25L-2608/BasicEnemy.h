#pragma once
#include "Enemy.h"
using namespace std;
using namespace sf;
class BasicEnemy : public Enemy {
private:
    CircleShape shape;   // the red circle you see on screen
    RectangleShape hpBar, hpBarBg;

public:
    BasicEnemy(float startX, float startY)
        // x, y, hp=100, speed=1.5, reward=10 gold
        : Enemy(startX, startY, 100, 1.5f, 10) {

        // red circle shape
        shape.setRadius(15);
        shape.setFillColor(Color(220, 50, 50));   // red
        shape.setOrigin(15, 15); // center the circle on x,y

        // hp bar background (dark red)
        hpBarBg.setSize(sf::Vector2f(30, 5));
        hpBarBg.setFillColor(Color(100, 0, 0));

        // hp bar foreground (green)
        hpBar.setSize(sf::Vector2f(30, 5));
        hpBar.setFillColor(Color(0, 200, 0));
    }

    void update() override {
        moveAlongPath(); 
    }

    void render(RenderWindow& window) override {
        // Draw the enemy circle at current position
        shape.setPosition(x, y);
        window.draw(shape);

        // Draw HP bar above the enemy
        hpBarBg.setPosition(x - 15, y - 25);//setting pos of hpbar above E
        window.draw(hpBarBg);

        // Scale green bar based on remaining HP (max 100)
        float hpPercent = (float)hp / 100.0f;
        hpBar.setSize(Vector2f(30 * hpPercent, 5));
        hpBar.setPosition(x - 15, y - 25);
        window.draw(hpBar);
    }
}; 

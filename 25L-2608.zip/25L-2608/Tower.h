#pragma once
#include "Entity.h"
#include "Enemy.h"
#include <vector>
#include <cmath>
using namespace std;
// Tower is abstract inherits from Entity
// All tower types inherit from this

class Tower : public Entity {
protected:
    float range;          // radius of shooting circle
    int damage;           // damage per shot
    float fireRate;       // shots per second
    float fireCooldown;   // timer counting down to next shot

public:
    Tower(float x, float y, int cost, float range, int damage, float fireRate)
        : Entity(x, y, 999), range(range),
        damage(damage), fireRate(fireRate), fireCooldown(0) {
    }

    // Find the closest enemy inside range
    Enemy* findTarget(vector<Enemy*>& enemies) {//pointer points to original obj,avoids copies
        Enemy* target = nullptr;
        float closestDist = range; // so starting with any enemy that is in range

        for (Enemy* e : enemies) {
            if (!e->isAlive()) continue;
            float dx = e->getX() - x;
            float dy = e->getY() - y;
            float dist = sqrt(dx * dx + dy * dy);
            if (dist <= closestDist) {
                closestDist = dist;
                target = e;
            }
        }
        return target; // nullptr if no enemy in range
    }

    //each tower attacks differently
    virtual void update() = 0;
    virtual void render(sf::RenderWindow& window) = 0;
    virtual void attack(Enemy* target) = 0;

    float getRange() const { return range; }
}; 

#include "Game.h"
#include <sstream>
#include <string>

std::vector<sf::Vector2f> Enemy::path;

static std::vector<sf::Vector2f> gamePath = {
    {  0.f, 250.f},
    {200.f, 250.f},
    {200.f, 450.f},
    {500.f, 450.f},
    {500.f, 150.f},
    {800.f, 150.f}
};

Game::Game()
    : window(sf::VideoMode(800, 600), "Tower Defense Game"),
    gold(200), lives(4),
    gameOver(false), gameWon(false),
    selectedTower(1),
    waveAnnounceTimer(0.f), lastWaveShown(0),
    towersPlacedThisWave(0) {

    window.setFramerateLimit(60);
    Enemy::setPath(gamePath);

    font.loadFromFile("C:\\Windows\\Fonts\\arial.ttf");

    goldText.setFont(font);
    goldText.setCharacterSize(20);
    goldText.setFillColor(sf::Color::Yellow);
    goldText.setPosition(10.f, 8.f);

    livesText.setFont(font);
    livesText.setCharacterSize(20);
    livesText.setFillColor(sf::Color(255, 80, 80));
    livesText.setPosition(200.f, 8.f);

    waveText.setFont(font);
    waveText.setCharacterSize(20);
    waveText.setFillColor(sf::Color::White);
    waveText.setPosition(400.f, 8.f);

    messageText.setFont(font);
    messageText.setCharacterSize(50);
    messageText.setPosition(150.f, 250.f);

    instructText.setFont(font);
    instructText.setCharacterSize(15);
    instructText.setFillColor(sf::Color::White);
    instructText.setPosition(10.f, 574.f);

    waveManager = new WaveManager(
        sf::Vector2f(0.f, 250.f),
        sf::Vector2f(800.f, 150.f)
    );

    setupPath();
}

Game::~Game() {
    for (Enemy* e : enemies) delete e;
    for (Tower* t : towers)  delete t;
    delete waveManager;
}

void Game::setupPath() {
    auto makeTile = [](float x, float y, float w, float h) {
        sf::RectangleShape r(sf::Vector2f(w, h));
        r.setPosition(x, y);
        r.setFillColor(sf::Color(60,120,30));
        return r;
        };
    pathTiles.push_back(makeTile(0.f, 220.f, 220.f, 60.f));
    pathTiles.push_back(makeTile(170.f, 220.f, 60.f, 260.f));
    pathTiles.push_back(makeTile(170.f, 420.f, 390.f, 60.f));
    pathTiles.push_back(makeTile(470.f, 120.f, 60.f, 360.f));
    pathTiles.push_back(makeTile(470.f, 120.f, 330.f, 60.f));
}

void Game::run() {
    sf::Clock clock;
    waveManager->startNextWave();

    while (window.isOpen()) {
        float dt = clock.restart().asSeconds();

        processEvents();

        if (!gameOver && !gameWon)
            update();

        // When wave ends � give bonus gold, remove towers,
        // reset counter, start next wave
        if (!waveManager->isWaveInProgress() &&
            !waveManager->isAllWavesDone() &&
            enemies.empty() &&
            !gameOver) {

            // Bonus gold increases each wave
            int bonusGold = 100 +
                (waveManager->getCurrentWave() * 50);
            gold += bonusGold;

            // Remove all towers from previous wave
            for (Tower* t : towers) delete t;
            towers.clear();
            towersPlacedThisWave = 0;

            waveManager->startNextWave();
        }

        // Check win condition
        if (waveManager->isAllWavesDone() && enemies.empty())
            gameWon = true;

        render();
    }
}

void Game::processEvents() {
    sf::Event event;
    while (window.pollEvent(event)) {

        if (event.type == sf::Event::Closed)
            window.close();

        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::Escape)
                window.close();
            if (event.key.code == sf::Keyboard::Num1)
                selectedTower = 1;
            if (event.key.code == sf::Keyboard::Num2)
                selectedTower = 2;
            if (event.key.code == sf::Keyboard::Num3)
                selectedTower = 3;
            if (event.key.code == sf::Keyboard::Num4)
                selectedTower = 4;
        }

        if (event.type == sf::Event::MouseButtonPressed)
            if (event.mouseButton.button == sf::Mouse::Left)
                placeTower((float)event.mouseButton.x,
                    (float)event.mouseButton.y);
    }
}

void Game::update() {
    float dt = 1.0f / 60.0f;

    // Detect new wave � trigger announcement
    if (waveManager->getCurrentWave() != lastWaveShown &&
        waveManager->isWaveInProgress()) {
        lastWaveShown = waveManager->getCurrentWave();
        waveAnnounceTimer = 3.0f;
    }
    if (waveAnnounceTimer > 0.f)
        waveAnnounceTimer -= dt;

    // Spawn enemies
    waveManager->update(enemies, dt);

    // Update all enemies
    for (Enemy* e : enemies) {
        e->update();
        if (e->reachedExit() && e->isAlive()) {
            lives--;
            e->takeDamage(99999);
            if (lives <= 0) gameOver = true;
        }
    }

    // Towers attack
    for (Tower* t : towers) {
        t->update();
        if (auto* ct = dynamic_cast<CannonTower*>(t))
            ct->tryShoot(enemies);
        else if (auto* st = dynamic_cast<SniperTower*>(t))
            st->tryShoot(enemies);
        else if (auto* mg = dynamic_cast<MachineGunTower*>(t))
            mg->tryShoot(enemies);
        else if (auto* sl = dynamic_cast<SlowTower*>(t))
            sl->slowEnemiesInRange(enemies);
    }

    // Remove dead enemies, collect gold
    for (int i = (int)enemies.size() - 1; i >= 0; i--) {
        if (!enemies[i]->isAlive()) {
            gold += enemies[i]->getReward();
            delete enemies[i];
            enemies.erase(enemies.begin() + i);
        }
    }
}

void Game::render() {
    window.clear(sf::Color(30, 80, 20));

    for (auto& tile : pathTiles)
        window.draw(tile);

    for (Tower* t : towers)
        t->render(window);

    for (Enemy* e : enemies)
        e->render(window);

    drawHUD();

    // Wave announcement � big yellow text center screen
    if (waveAnnounceTimer > 0.f) {
        sf::Text waveAnnounce;
        waveAnnounce.setFont(font);
        waveAnnounce.setCharacterSize(60);
        waveAnnounce.setFillColor(sf::Color(255, 200, 0));
        waveAnnounce.setStyle(sf::Text::Bold);
        waveAnnounce.setString(
            "WAVE " +
            std::to_string(waveManager->getCurrentWave()) +
            "  /  " +
            std::to_string(waveManager->getTotalWaves())
        );
        waveAnnounce.setPosition(150.f, 270.f);
        window.draw(waveAnnounce);
    }

    // Game over screen
    if (gameOver) {
        sf::RectangleShape overlay(sf::Vector2f(800.f, 600.f));
        overlay.setFillColor(sf::Color(0, 0, 0, 150));
        window.draw(overlay);
        messageText.setString("GAME OVER!");
        messageText.setFillColor(sf::Color::Red);
        messageText.setPosition(200.f, 260.f);
        window.draw(messageText);
    }

    // Win screen
    if (gameWon) {
        sf::RectangleShape overlay(sf::Vector2f(800.f, 600.f));
        overlay.setFillColor(sf::Color(0, 0, 0, 150));
        window.draw(overlay);
        messageText.setString("YOU WIN!");
        messageText.setFillColor(sf::Color::Green);
        messageText.setPosition(230.f, 260.f);
        window.draw(messageText);
    }

    window.display();
}

void Game::drawHUD() {
    // Top dark bar
    sf::RectangleShape topBar(sf::Vector2f(800.f, 40.f));
    topBar.setFillColor(sf::Color(10, 10, 10, 220));
    window.draw(topBar);

    std::ostringstream gs, ls, ws;
    gs << "Gold: " << gold;
    ls << "Lives: " << lives;
    ws << "Wave: " << waveManager->getCurrentWave()
        << " / " << waveManager->getTotalWaves();

    goldText.setString(gs.str());
    livesText.setString(ls.str());
    waveText.setString(ws.str());

    window.draw(goldText);
    window.draw(livesText);
    window.draw(waveText);

    // Bottom instruction bar
    sf::RectangleShape botBar(sf::Vector2f(800.f, 28.f));
    botBar.setPosition(0.f, 572.f);
    botBar.setFillColor(sf::Color(10, 10, 10, 220));
    window.draw(botBar);

    int wave = waveManager->getCurrentWave();

    // Locked towers show (W2),(W3),(W4) until unlocked
    std::string inst = "[1]Cannon-100g ";

    if (wave >= 2)
        inst += "[2]Sniper-150g ";
    else
        inst += "[2]Sniper(W2) ";

    if (wave >= 3)
        inst += "[3]MG-125g ";
    else
        inst += "[3]MG(W3) ";

    if (wave >= 4)
        inst += "[4]Slow-75g ";
    else
        inst += "[4]Slow(W4) ";

    std::string names[] = { "", "Cannon", "Sniper",
                               "MachineGun", "Slow" };
    inst += "| Now: " + names[selectedTower];
    inst += " | Towers: " +
        std::to_string(towersPlacedThisWave) + "/2";

    instructText.setString(inst);
    window.draw(instructText);
}

void Game::placeTower(float x, float y) {
    if (y < 42.f || y > 570.f) return;
    if (towersPlacedThisWave >= 2) return;

    int wave = waveManager->getCurrentWave();

    switch (selectedTower) {
    case 1: // Cannon � wave 1+
        if (gold >= 100) {
            towers.push_back(new CannonTower(x, y));
            gold -= 100;
            towersPlacedThisWave++;
        }
        break;

    case 2: // Sniper � wave 2+
        if (wave < 2) return;
        if (gold >= 150) {
            towers.push_back(new SniperTower(x, y));
            gold -= 150;
            towersPlacedThisWave++;
        }
        break;

    case 3: // MachineGun � wave 3+
        if (wave < 3) return;
        if (gold >= 125) {
            towers.push_back(new MachineGunTower(x, y));
            gold -= 125;
            towersPlacedThisWave++;
        }
        break;

    case 4: // Slow � wave 4+
        if (wave < 4) return;
        if (gold >= 75) {
            towers.push_back(new SlowTower(x, y));
            gold -= 75;
            towersPlacedThisWave++;
        }
        break;
    }
}
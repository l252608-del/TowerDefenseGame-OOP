#pragma once
#include "Tower.h"
using namespace std;
using namespace sf;

class SlowTower : public Tower {
private:
    RectangleShape base;
    CircleShape rangeCircle;

public:
    SlowTower(float x, float y)
        //cost,range,damage,firerate
        : Tower(x, y, 75, 110.0f, 0, 2.0f) {

        base.setSize(Vector2f(40, 40));
        base.setFillColor(Color(0, 160, 200)); // cyan
        base.setOrigin(20, 20);

        rangeCircle.setRadius(range);
        rangeCircle.setFillColor(Color(0, 200, 255, 20));
        rangeCircle.setOutlineColor(Color(0, 200, 255, 100));
        rangeCircle.setOutlineThickness(1);
        rangeCircle.setOrigin(range, range);
    }

    void attack(Enemy* target) override {
        // no damage only slows
        if (target) target->applySlow(0.5f);
    }

    void slowEnemiesInRange(vector<Enemy*>& enemies) {
        if (fireCooldown > 0) return;
        for (Enemy* e : enemies) {
            if (!e->isAlive()) continue;
            float dx = e->getX() - x;
            float dy = e->getY() - y;
            float dist = sqrt(dx * dx + dy * dy);
            if (dist <= range)
                e->applySlow(0.5f);
        }
        fireCooldown = 1.0f / fireRate;
    }

    void update() override {
        if (fireCooldown > 0) fireCooldown -= 1.0f / 60.0f;
    }

    void render(RenderWindow& window) override {
        rangeCircle.setPosition(x, y);
        window.draw(rangeCircle);
        base.setPosition(x, y);
        window.draw(base);
    }
};

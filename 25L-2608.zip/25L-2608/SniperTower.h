#pragma once
#include "Tower.h"
using namespace std;
using namespace sf;
class SniperTower : public Tower {
private:
   RectangleShape base;
   CircleShape rangeCircle;

public:
    SniperTower(float x, float y)
        //cost,range,damage,firerate
        : Tower(x, y, 150, 220.0f, 80, 0.5f) {

        base.setSize(Vector2f(40, 40));
        base.setFillColor(Color(20, 120, 60)); // dark green
        base.setOrigin(20, 20);

        rangeCircle.setRadius(range);
        rangeCircle.setFillColor(Color::Transparent);
        rangeCircle.setOutlineColor(Color(50, 200, 100, 70));
        rangeCircle.setOutlineThickness(1);
        rangeCircle.setOrigin(range, range);
    }

    void attack(Enemy* target) override {
        if (target) target->takeDamage(damage);
    }

    void update() override {
        if (fireCooldown > 0) fireCooldown -= 1.0f / 60.0f;
    }

    void tryShoot(vector<Enemy*>& enemies) {
        if (fireCooldown <= 0) {
            Enemy* target = findTarget(enemies);
            if (target) {
                attack(target);
                fireCooldown = 1.0f / fireRate;  //60 frames =1  sec
            }
        }
    }

    void render(RenderWindow& window) override {
        rangeCircle.setPosition(x, y);
        window.draw(rangeCircle);
        base.setPosition(x, y);
        window.draw(base);
    }
};

#pragma once
#include "Entity.h"
#include <vector>
#include <cmath>
using namespace std;
using namespace sf;
class Enemy : public Entity {
protected:
    float speed;
    float baseSpeed;      // original speed before slow
    float slowTimer;      // how long slow effect lasts
    int reward;
    int waypointIndex;
    static vector<Vector2f> path;

public:
    Enemy(float x, float y, int hp, float speed, int reward)
        : Entity(x, y, hp), speed(speed), baseSpeed(speed),
        slowTimer(0.f), reward(reward), waypointIndex(0) {
    }

    virtual void update() = 0;
    virtual void render(RenderWindow& window) = 0;

    bool moveAlongPath() {
        if (waypointIndex >= (int)path.size()) return true;

        Vector2f target = path[waypointIndex];
        float dx = target.x - x;
        float dy = target.y - y;
        float dist = sqrt(dx * dx + dy * dy);

        if (dist < speed) {
            x = target.x;// now enemies are exactly on waypoint 
            y = target.y;
            waypointIndex++;//setting the next target to which E will move
        }
        else {
            x += (dx / dist) * speed;
            y += (dy / dist) * speed;
        }
        return false;
    }

    // slow effect called by SlowTower
    void applySlow(float factor) {
        speed = baseSpeed * factor;
        slowTimer = 2.0f; //soafter 120 sec it will become 0f  again
    }

    // call every frame to count down slow timer
    void updateSlow() {
        if (slowTimer > 0.f) {
            slowTimer -= 1.0f / 60.0f;
            if (slowTimer <= 0.f) speed = baseSpeed;
        }
    }

    //  make it virtual so flyingenemy can override it
    virtual bool reachedExit() const {
        return waypointIndex >= (int)path.size();
    }

    int  getReward() const { return reward; }
    float getSpeed() const { return speed; }

    static void setPath(vector<Vector2f> p) { path = p; }
};
#pragma once
#include "Enemy.h"
using namespace std;
using namespace sf;

class FastEnemy : public Enemy {
private:
    CircleShape shape;
    RectangleShape hpBar, hpBarBg;

public:
    FastEnemy(float startX, float startY)
        //hp,sped,reward
        : Enemy(startX, startY, 50, 3.0f, 15) {

        shape.setRadius(10);
        shape.setFillColor(Color(255, 200, 0)); // yellow
        shape.setOrigin(10, 10);

        hpBarBg.setSize(Vector2f(20.f, 4.f));
        hpBarBg.setFillColor(Color(100, 80, 0));

        hpBar.setSize(Vector2f(20.f, 4.f));
        hpBar.setFillColor(Color(0, 200, 0));
    }

    void update() override {
        updateSlow();
        moveAlongPath();
    }

    void render(RenderWindow& window) override {
        shape.setPosition(x, y);
        window.draw(shape);

        hpBarBg.setPosition(x - 10, y - 20);
        window.draw(hpBarBg);

        float pct = (float)hp / 50.0f;
        hpBar.setSize(Vector2f(20.f * pct, 4.f));
        hpBar.setPosition(x - 10, y - 20);
        window.draw(hpBar);
    }
};
#pragma once
#include "Enemy.h"
using namespace std;
using namespace sf;
class FlyingEnemy : public Enemy {
private:
    CircleShape shape;
    RectangleShape hpBar, hpBarBg;
    Vector2f exitPoint;
    bool reachedDestination;  // tracks if it reached exit

public:
    FlyingEnemy(float startX, float startY, Vector2f exit)
        : Enemy(startX, startY, 80, 2.0f, 25),
        exitPoint(exit), reachedDestination(false) {

        shape.setRadius(13);
        shape.setFillColor(Color(150, 50, 220)); // purple
        shape.setOrigin(13, 13);

        hpBarBg.setSize(Vector2f(26.f, 4.f));
        hpBarBg.setFillColor(Color(80, 0, 120));

        hpBar.setSize(Vector2f(26.f, 4.f));
        hpBar.setFillColor(Color(0, 200, 0));
    }

    void update() override {
        float dx = exitPoint.x - x;
        float dy = exitPoint.y - y;
        float dist = sqrt(dx * dx + dy * dy);

        if (dist < speed) {
            x = exitPoint.x;
            y = exitPoint.y;
            reachedDestination = true;  // mark reached
        }
        else {
            x += (dx / dist) * speed;
            y += (dy / dist) * speed;
        }
    }

    void render(RenderWindow& window) override {
        shape.setPosition(x, y);
        window.draw(shape);

        hpBarBg.setPosition(x - 13, y - 24);
        window.draw(hpBarBg);

        float pct = (float)hp / 80.0f;
        hpBar.setSize(Vector2f(26.f * pct, 4.f));
        hpBar.setPosition(x - 13, y - 24);
        window.draw(hpBar);
    }

    // this overrides the base class
    bool reachedExit() const override {
        return reachedDestination;
    }
};
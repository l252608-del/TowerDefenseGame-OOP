#pragma once
#include <SFML/Graphics.hpp>

// Entity is the base class for all objects in the game
// It is abstract you cannot create an entity directly
// Both enemy and tower will inherit from this

class Entity {
protected:
    float x, y;      // position on screen (pixels), in float cuz movements smoother with decimal values
    int hp;          // health points
    bool alive;      // is this object still alive

public:
    Entity(float x, float y, int hp)
        : x(x), y(y), hp(hp), alive(true) {
    }

    // pure virtual every child MUST implement these
    virtual void update() = 0; // kept =0 cuz diff behavior for tower and enemy
    virtual void render(sf::RenderWindow& window) = 0;

    virtual void takeDamage(int dmg) {
        hp -= dmg;
        if (hp <= 0) alive = false;
    }

    // Getters
    bool isAlive()  const { return alive; }
    float getX()    const { return x; }
    float getY()    const { return y; }
    int getHP()     const { return hp; }

    virtual ~Entity() {}
};

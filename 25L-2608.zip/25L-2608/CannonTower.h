#pragma once
#include "Tower.h"
using namespace std;
using namespace sf;
class CannonTower : public Tower {
private:
    RectangleShape base;   // the tower square
    CircleShape rangeCircle; // shows the range

public:
    // cost=100 gold, range=120px, damage=40, fireRate=1 shot/sec
    CannonTower(float x, float y)
        : Tower(x, y, 100, 120.0f, 40, 1.0f) {

        // Blue square for the tower
        base.setSize(Vector2f(40, 40));
        base.setFillColor(Color(30, 100, 200));
        base.setOrigin(20, 20);

        // Dashed circle showing range (just outline)
        rangeCircle.setRadius(range);
        rangeCircle.setFillColor(sf::Color::Transparent);
        rangeCircle.setOutlineColor(sf::Color(100, 150, 255, 80));
        rangeCircle.setOutlineThickness(1);
        rangeCircle.setOrigin(range, range);
    }

    void attack(Enemy* target) override {
        if (target) target->takeDamage(damage);
    }

    void update() override {
        // Reduce cooldown each frame (at 60fps, 1/60 per frame)
        if (fireCooldown > 0) fireCooldown -= 1.0f / 60.0f;
    }

    // Call this every frame � handles timing and shooting
    void tryShoot(vector<Enemy*>& enemies) {
        if (fireCooldown <= 0) {
            Enemy* target = findTarget(enemies);
            if (target) {
                attack(target);
                fireCooldown = 1.0f / fireRate; // reset cooldown, if fire rate high shooting speed high and less cooldown(rload)
            }
        }
    }

    void render(RenderWindow& window) override {
        // draw range circle first
        rangeCircle.setPosition(x, y);
        window.draw(rangeCircle);

        // draw tower square then
        base.setPosition(x, y);
        window.draw(base);
    }
}; 

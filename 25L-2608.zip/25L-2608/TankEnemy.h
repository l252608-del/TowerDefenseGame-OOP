#pragma once
#include "Enemy.h"
using namespace std;
using namespace sf;
class TankEnemy : public Enemy {
private:
    CircleShape shape;
    RectangleShape hpBar, hpBarBg;
    int maxHp;

public:
    TankEnemy(float startX, float startY)
        : Enemy(startX, startY, 400, 0.6f, 40), maxHp(400) {

        shape.setRadius(22);
        shape.setFillColor(Color(120, 0, 0)); // dark red
        shape.setOrigin(22, 22);

        hpBarBg.setSize(Vector2f(44.f, 6.f));
        hpBarBg.setFillColor(sf::Color(60, 0, 0));

        hpBar.setSize(Vector2f(44.f, 6.f));
        hpBar.setFillColor(Color(0, 200, 0));
    }

    void update() override {
        updateSlow();
        moveAlongPath();
    }

    void render(RenderWindow& window) override {
        shape.setPosition(x, y);
        window.draw(shape);

        hpBarBg.setPosition(x - 22, y - 35);
        window.draw(hpBarBg);

        float pct = (float)hp / (float)maxHp;
        hpBar.setSize(Vector2f(44.f * pct, 6.f));
        hpBar.setPosition(x - 22, y - 35);
        window.draw(hpBar);
    }
};
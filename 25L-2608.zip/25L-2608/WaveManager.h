#pragma once
#include <vector>
#include "BasicEnemy.h"
#include "FastEnemy.h"
#include "TankEnemy.h"
#include "FlyingEnemy.h"

class WaveManager {
private:
    int currentWave;
    int totalWaves;
    float spawnTimer;
    float spawnInterval;
    int enemiesLeftToSpawn;
    bool waveInProgress;
    bool allWavesDone;
    sf::Vector2f startPos;
    sf::Vector2f exitPos;
    int spawnCounter;

public:
    WaveManager(sf::Vector2f start, sf::Vector2f exit)
        : currentWave(0), totalWaves(5),
        spawnTimer(0.f), spawnInterval(1.5f),
        enemiesLeftToSpawn(0), waveInProgress(false),
        allWavesDone(false), startPos(start),
        exitPos(exit), spawnCounter(0) {
    }

    void startNextWave() {
        if (currentWave >= totalWaves) {
            allWavesDone = true;
            return;
        }
        currentWave++;
        waveInProgress = true;
        spawnTimer = 0.f;
        spawnCounter = 0;
        enemiesLeftToSpawn = 5 + (currentWave * 3);
    }

    void update(std::vector<Enemy*>& enemies, float dt) {
        if (!waveInProgress) return;

        spawnTimer -= dt;

        if (spawnTimer <= 0.f && enemiesLeftToSpawn > 0) {
            spawnEnemy(enemies);
            enemiesLeftToSpawn--;
            spawnTimer = spawnInterval;
        }

        if (enemiesLeftToSpawn <= 0 && enemies.empty())
            waveInProgress = false;
    }

    void spawnEnemy(std::vector<Enemy*>& enemies) {
        int type;
        if (currentWave <= 2)
            type = spawnCounter % 2;
        else
            type = spawnCounter % 4;
        spawnCounter++;

        switch (type) {
        case 0:
            enemies.push_back(
                new BasicEnemy(startPos.x, startPos.y));// make enemy and add in enemy list
            break;
        case 1:
            enemies.push_back(
                new FastEnemy(startPos.x, startPos.y));
            break;
        case 2:
            enemies.push_back(
                new TankEnemy(startPos.x, startPos.y));
            break;
        case 3:
            enemies.push_back(
                new FlyingEnemy(startPos.x, startPos.y, exitPos));
            break;
        }
    }

    bool isWaveInProgress() const { return waveInProgress; }
    bool isAllWavesDone()   const { return allWavesDone; }
    int  getCurrentWave()   const { return currentWave; }
    int  getTotalWaves()    const { return totalWaves; }
};

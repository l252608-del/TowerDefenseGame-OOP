#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include "BasicEnemy.h"
#include "FastEnemy.h"
#include "TankEnemy.h"
#include "FlyingEnemy.h"
#include "CannonTower.h"
#include "SniperTower.h"
#include "MachineGunTower.h"
#include "SlowTower.h"
#include "WaveManager.h"

class Game {
private:
    sf::RenderWindow window;

    std::vector<Enemy*> enemies;
    std::vector<Tower*> towers;

    int  gold;
    int  lives;
    bool gameOver;
    bool gameWon;

    sf::Font font;
    sf::Text goldText;
    sf::Text livesText;
    sf::Text waveText;
    sf::Text messageText;
    sf::Text instructText;

    std::vector<sf::RectangleShape> pathTiles;

    WaveManager* waveManager;

    int selectedTower;

    float waveAnnounceTimer;
    int   lastWaveShown;

    int towersPlacedThisWave;

public:
    Game();
    ~Game();
    void run();

private:
    void processEvents();
    void update();
    void render();
    void setupPath();
    void drawHUD();
    void placeTower(float x, float y);
};
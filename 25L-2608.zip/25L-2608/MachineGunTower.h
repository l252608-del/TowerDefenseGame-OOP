#pragma once
#include "Tower.h"
using namespace std;
using namespace sf;
class MachineGunTower : public Tower {
private:
    sf::RectangleShape base;
    sf::CircleShape rangeCircle;

public:
    MachineGunTower(float x, float y)
        //cost,range,damage,firerate
        : Tower(x, y, 125, 130.0f, 20, 5.0f) {

        base.setSize(Vector2f(40, 40));
        base.setFillColor(Color(180, 60, 0)); // orange
        base.setOrigin(20, 20);

        rangeCircle.setRadius(range);
        rangeCircle.setFillColor(Color::Transparent);
        rangeCircle.setOutlineColor(Color(255, 140, 0, 70));
        rangeCircle.setOutlineThickness(1);
        rangeCircle.setOrigin(range, range);
    }

    void attack(Enemy* target) override {
        if (target) target->takeDamage(damage);
    }

    void update() override {
        if (fireCooldown > 0) fireCooldown -= 1.0f / 60.0f;
    }

    void tryShoot(vector<Enemy*>& enemies) {
        if (fireCooldown <= 0) {
            Enemy* target = findTarget(enemies);
            if (target) {
                attack(target);
                fireCooldown = 1.0f / fireRate;
            }
        }
    }

    void render(RenderWindow& window) override {
        rangeCircle.setPosition(x, y);
        window.draw(rangeCircle);
        base.setPosition(x, y);
        window.draw(base);
    }
};
